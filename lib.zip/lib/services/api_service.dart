import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';

class ApiService {
  // 🟢 Update this to your active Render or Local Server URL
  static const String baseUrl = "https://sewa-o947.onrender.com";

  // ================= TOKEN & ROLE STORAGE =================
  
  static Future<void> saveAuthData(String role) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString("user_role", role);
  }

  static Future<String?> _getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString("token");
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove("token");
    await prefs.remove("user_role");
  }

  // ================= RESPONSE DECODER =================
  
  static Future<Map<String, dynamic>> _decodeResponse(http.Response res) async {
    try {
      if (res.body.trim().startsWith("<")) {
        return {"success": false, "message": "Server error: HTML returned instead of JSON."};
      }
      final data = jsonDecode(res.body);
      if (data is Map<String, dynamic>) return data;
      return {"success": false, "message": "Unexpected response format"};
    } catch (e) {
      return {"success": false, "message": "Invalid JSON response from server"};
    }
  }

  // ================= AUTHENTICATION =================

  static Future<Map<String, dynamic>> login(String email, String password) async {
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/login"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"email": email, "password": password}),
      );
      final data = await _decodeResponse(res);

      if (data["success"] == true && data["token"] != null) {
        String role = data["role"] ?? (data["user"] != null ? data["user"]["role"] : "user");
        await saveAuthData(role);
      }
      return data;
    } catch (e) {
      return {"success": false, "message": "Network connection error"};
    }
  }

  static Future<Map<String, dynamic>> register(
    String name,
    String email,
    String password,
    String mobile,
    String address,
    String role, 
  ) async {
    try {
      final res = await http.post(
        Uri.parse("$baseUrl/register"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "name": name,
          "email": email,
          "password": password,
          "mobile": mobile,
          "address": address,
          "role": role, 
        }),
      );
      return await _decodeResponse(res); 
    } catch (e) {
      return {"success": false, "message": "Registration server error"};
    }
  }

  // ================= USER & PROFILE =================

  static Future<Map<String, dynamic>> getProfile() async {
    final token = await _getToken();
    if (token == null) return {"success": false, "message": "Not logged in"};

    final res = await http.get(
      Uri.parse("$baseUrl/profile"),
      headers: {
        "Authorization": "Bearer $token", 
        "Content-Type": "application/json"
      },
    );
    return await _decodeResponse(res);
  }

  static Future<Map<String, dynamic>> updateProfile(Map data) async {
    try {
      final token = await _getToken();
      if (token == null) return {"success": false, "message": "Not logged in"};

      final res = await http.patch(
        Uri.parse("$baseUrl/update-profile"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token"
        },
        body: jsonEncode(data),
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Error updating profile"};
    }
  }

  // ================= BIN & SCANNER =================

  static Future<Map<String, dynamic>> getUserHistory() async {
    final token = await _getToken();
    if (token == null) return {"success": false, "message": "Not logged in"};

    try {
      final res = await http.get(
        Uri.parse("$baseUrl/user/history"), 
        headers: {
          "Authorization": "Bearer $token", 
          "Content-Type": "application/json"
        },
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Connection error"};
    }
  }

  static Future<List<dynamic>> getNearestBins(double lat, double lng) async {
    final token = await _getToken();
    if (token == null) return [];

    final res = await http.get(
      Uri.parse("$baseUrl/nearest-bins?lat=$lat&lng=$lng"),
      headers: {"Authorization": "Bearer $token"},
    );

    final data = await _decodeResponse(res);
    return (data["success"] == true && data["nearestBins"] is List) ? data["nearestBins"] : [];
  }

  static Future<Map<String, dynamic>> requestBinUnlock(String binId) async {
    try {
      final token = await _getToken();
      final response = await http.post(
        Uri.parse('$baseUrl/bin/scan-to-open'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({'binId': binId}),
      );
      return jsonDecode(response.body); 
    } catch (e) {
      return {'success': false, 'message': 'Connection error'};
    }
  }

  // ================= COMMUNITY API METHODS =================
  
  static Future<Map<String, dynamic>> assignCommunity(String keyword, String name) async {
    try {
      final token = await _getToken();
      final res = await http.post(Uri.parse('$baseUrl/admin/assign-community'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
        body: jsonEncode({"addressKeyword": keyword, "communityName": name}),
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Connection error"};
    }
  }

  static Future<Map<String, dynamic>> getCommunityCampaigns() async {
    try {
      final token = await _getToken();
      final res = await http.get(Uri.parse('$baseUrl/community/campaigns'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Connection error"};
    }
  }

  static Future<Map<String, dynamic>> donateToCampaign(String campaignId, int amount) async {
    try {
      final token = await _getToken();
      final res = await http.post(Uri.parse('$baseUrl/community/donate'),
        headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer $token'},
        body: jsonEncode({"campaignId": campaignId, "amount": amount}),
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Connection error"};
    }
  }

  // ================= ADMINISTRATION =================

  static Future<Map<String, dynamic>> getAdminStats() async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/admin/stats'),
        headers: {
          'Content-Type': 'application/json',
        },
      );
      return jsonDecode(response.body);
    } catch (e) {
      debugPrint("❌ ApiService Exception: $e");
      return {"success": false, "message": "Check server connection"};
    }
  }

  static Future<Map<String, dynamic>> markBinEmpty(String binId) async {
    final token = await _getToken();
    final res = await http.post(
      Uri.parse("$baseUrl/admin/empty-bin"), 
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer $token"
      },
      body: jsonEncode({"binId": binId}),
    );
    return await _decodeResponse(res);
  }

  // 🟢 NEW: Assign Smart Glove to User (Triggered from Admin Drawer)
  static Future<Map<String, dynamic>> assignGlove(String email, String gloveId) async {
    try {
      final token = await _getToken();
      if (token == null) return {"success": false, "message": "Not logged in"};

      final res = await http.post(
        Uri.parse("$baseUrl/admin/assign-glove"),
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer $token"
        },
        body: jsonEncode({"userEmail": email, "gloveId": gloveId}),
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Connection error"};
    }
  }

  // ================= REHAB GAME =================

  static Future<Map<String, dynamic>> redeemGame() async {
    try {
      final token = await _getToken();
      final res = await http.post(
        Uri.parse("$baseUrl/redeem-game"),
        headers: {"Content-Type": "application/json", "Authorization": "Bearer $token"},
      );
      return await _decodeResponse(res);
    } catch (e) {
      return {"success": false, "message": "Redemption error"};
    }
  }

  static Future<void> updateGameLevel(int newLevel) async {
    try {
      final token = await _getToken();
      await http.post(
        Uri.parse("$baseUrl/update-game-progress"),
        headers: {"Content-Type": "application/json", "Authorization": "Bearer $token"},
        body: jsonEncode({"newLevel": newLevel}),
      );
    } catch (e) {
      debugPrint("Game sync failed");
    }
  }
}
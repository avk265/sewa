import 'package:flutter/material.dart';
import 'package:sewa/services/api_service.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;

class DrawerMenu extends StatefulWidget {
  final List<String> alerts; 
  const DrawerMenu({super.key, this.alerts = const []});

  @override
  State<DrawerMenu> createState() => _DrawerMenuState();
}

class _DrawerMenuState extends State<DrawerMenu> {
  Map<String, dynamic>? userData;
  bool isProcessing = false;
  String _userRole = "user"; 
  
  // 🟢 1. MAKE THESE STATIC so they survive when the drawer closes
  static final List<String> _staticAlerts = [];
  static IO.Socket? _socket;
  static bool _isInitialized = false;

  // 🟢 LOGIC: Merge constructor alerts with static alerts
  List<String> get combinedAlerts {
    final all = <String>{...widget.alerts, ..._staticAlerts};
    return all.toList();
  }

  bool get hasUnreadAlerts => combinedAlerts.isNotEmpty;

  @override
  void initState() {
    super.initState();
    _loadInitialData();
  }
  
  Future<void> _loadInitialData() async {
    final prefs = await SharedPreferences.getInstance();
    _userRole = prefs.getString("user_role") ?? "user";

    // Initialize Admin Socket only if Role is Admin
    if (_userRole == "admin") {
      _initAdminSocket();
    }

    final res = await ApiService.getProfile();
    if (mounted && res["success"] == true) {
      setState(() {
        userData = res["user"];
      });
    }
  }

  // 🟢 Real-time Socket Connection for Admin Alerts
  // 🟢 Real-time Socket Connection for Admin Alerts
  void _initAdminSocket() {
    // 🛡️ Prevent multiple connections
    if (_isInitialized || _userRole != "admin") return;
    _isInitialized = true;

    _socket = IO.io(ApiService.baseUrl, <String, dynamic>{
      'transports': ['websocket'], // 🟢 Vital for Render/Cloud compatibility
      'autoConnect': true,
    });

    // 🎧 Listen for the specific SEWA Admin "Shout"
    _socket?.on('admin-notification', (data) {
      String msg = data['message'] ?? "Critical Bin Alert";
      
      if (!combinedAlerts.contains(msg)) {
        combinedAlerts.add(msg);
        debugPrint("🚨 Drawer Socket Captured: $msg");
        
        // Refresh UI only if the Drawer is currently open
        if (mounted) setState(() {}); 
      }
    });
  }


  // 🟢 Rehab Game Redemption (Citizen)
  // 🟢 Rehab Game Redemption (Citizen)
  Future<void> _handleRedemption() async {
    // 🟢 FIX: Capture messenger before async gap
    final messenger = ScaffoldMessenger.of(context);
    
    setState(() => isProcessing = true);
    final res = await ApiService.redeemGame();
    setState(() => isProcessing = false);

    if (res["success"] == true && mounted) {
      messenger.showSnackBar(
        const SnackBar(content: Text("🎉 Rehab Game Unlocked for 60 Days!"), backgroundColor: Colors.green)
      );
      _loadInitialData(); 
    } else if (mounted) {
      messenger.showSnackBar(
        SnackBar(content: Text("❌ ${res['message']}"), backgroundColor: Colors.red)
      );
    }
  }

  // 🟢 Glove Assignment Dialog (Admin)
  // 🟢 Glove Assignment Dialog (Admin)
  void _showAssignGloveDialog(BuildContext context) {
    final emailCtrl = TextEditingController();
    final gloveCtrl = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Assign Smart Glove"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Enter user email and hardware ID to grant Rehab Access.", style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 10),
            TextField(
              controller: emailCtrl, 
              decoration: const InputDecoration(labelText: "User Email", prefixIcon: Icon(Icons.email_outlined)),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: gloveCtrl, 
              decoration: const InputDecoration(labelText: "Glove Device ID", prefixIcon: Icon(Icons.hardware)),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey, foregroundColor: Colors.white),
            onPressed: () async {
              // 🟢 FIX: Capture messenger
              final messenger = ScaffoldMessenger.of(context);

              Navigator.pop(context);
              messenger.showSnackBar(const SnackBar(content: Text("Processing Assignment...")));
              
             
              final res = await ApiService.assignGlove(emailCtrl.text, gloveCtrl.text); 
              if (res["success"] == true) {
                messenger.showSnackBar(
                  SnackBar(
                    content: Text("Glove ${gloveCtrl.text} linked successfully!"),
                    backgroundColor: Colors.green,
                  ),
                );
              } else {
                messenger.showSnackBar(
                  SnackBar(
                    content: Text("Error: ${res['message']}"),
                    backgroundColor: Colors.red,
                  ),
                );
              }
            }, 
            child: const Text("Assign Access")
          )
        ]
      )
    );
  }

  // 🟢 System Alerts Dialog (Admin)
  void _showSystemAlertsDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Critical Bin Alerts"),
        content: SizedBox(
          width: double.maxFinite,
          child: combinedAlerts.isEmpty 
            ? const Text("No active alerts.")
            : ListView.builder(
                shrinkWrap: true,
                itemCount: combinedAlerts.length,
                itemBuilder: (context, index) => Card(
                  color: Colors.red.shade50,
                  child: ListTile(
                    leading: const Icon(Icons.warning, color: Colors.red),
                    title: Text(combinedAlerts[index]),
                  ),
                ),
              ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Close")),
          if (hasUnreadAlerts)
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
              onPressed: () {
                setState(() => _staticAlerts.clear());
                // Note: constructor alerts must be cleared in the Dashboard
                Navigator.pop(context);
              },
              child: const Text("Clear Background Alerts"),
            )
        ],
      ),
    );
  }

  // 🟢 Community Assignment Dialog (Admin)
  // 🟢 Community Assignment Dialog (Admin)
  void _showAssignCommunityDialog(BuildContext context) {
    final addressCtrl = TextEditingController();
    final communityCtrl = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Create Community Group"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Group users by address keyword (e.g., 'Kollam' or 'Hostel A').", style: TextStyle(fontSize: 12, color: Colors.grey)),
            const SizedBox(height: 10),
            TextField(
              controller: addressCtrl, 
              decoration: const InputDecoration(labelText: "Address Keyword", prefixIcon: Icon(Icons.location_city))
            ),
            const SizedBox(height: 10),
            TextField(
              controller: communityCtrl, 
              decoration: const InputDecoration(labelText: "Community Name", prefixIcon: Icon(Icons.group))
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blueGrey, foregroundColor: Colors.white),
            onPressed: () async {
              // 🟢 FIX: Capture the messenger BEFORE popping the context
              final messenger = ScaffoldMessenger.of(context); 
              
              Navigator.pop(context); // Close the dialog
              messenger.showSnackBar(const SnackBar(content: Text("Grouping Users...")));
              
              final res = await ApiService.assignCommunity(addressCtrl.text, communityCtrl.text);
              if (mounted) {
                messenger.showSnackBar(
                  SnackBar(
                    content: Text(res['message'] ?? "Community updated"), 
                    backgroundColor: res['success'] == true ? Colors.green : Colors.red
                  )
                );
              }
            }, 
            child: const Text("Group Users")
          )
        ]
      )
    );
  }
  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // 🟢 Extract User Metrics
    final int currentBalance = userData?["greenPoints"] ?? 0;
    final int savedLevel = userData?["rehabGameLevel"] ?? 1;
    final String? expiryStr = userData?["rehabGameExpiry"];
    final String? communityName = userData?["communityName"]; 
    
    final DateTime? expiryDate = expiryStr != null ? DateTime.parse(expiryStr) : null;
    final bool isGameActive = expiryDate != null && expiryDate.isAfter(DateTime.now());
    final bool canAfford = currentBalance >= 100;
    // 🎨 Dynamic Header Color
    final Color activeThemeColor = _userRole == "admin" ? Colors.blueGrey : Theme.of(context).primaryColor; 

    return Drawer(
      child: Column(
        children: [
          // ==============================
          // 1. DRAWER HEADER
          // ==============================
          Container(
            width: double.infinity,
            padding: EdgeInsets.only(
              top: MediaQuery.of(context).padding.top + 20,
              bottom: 20,
              left: 20,
              right: 20,
            ),
            decoration: BoxDecoration(color: activeThemeColor),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  radius: 35,
                  backgroundColor: Colors.white,
                  child: Text(
                    userData?["name"]?.substring(0, 1).toUpperCase() ?? (_userRole == "admin" ? "A" : "U"),
                    style: TextStyle(fontSize: 32, color: activeThemeColor, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 15),
                Text(
                  userData?["name"] ?? "SEWA User",
                  style: const TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.bold),
                ),
                Text(
                  userData?["email"] ?? "loading...",
                  style: const TextStyle(color: Colors.white70, fontSize: 14),
                ),
                const SizedBox(height: 12),
                
                // Balance Pill (Citizens Only)
                if (_userRole != "admin")
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.eco, color: Colors.white, size: 16),
                        const SizedBox(width: 6),
                        Text(
                          "Balance: $currentBalance pts",
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),

          // ==============================
          // 2. NAVIGATION LINKS
          // ==============================
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                ListTile(
                  leading: const Icon(Icons.home_rounded),
                  title: const Text("Dashboard"),
                  onTap: () {
                    Navigator.pop(context); // Close Drawer
                    Navigator.pushReplacementNamed(context, _userRole == "admin" ? "/adminDashboard" : "/dashboard");
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.person_outline),
                  title: const Text("My Profile"),
                  onTap: () {
                    Navigator.pop(context); // Close Drawer
                    Navigator.pushNamed(context, "/profile");
                  },
                ),

                const Divider(),

                // -----------------------------
                // 🔒 ADMIN SECTION
                // -----------------------------
                if (_userRole == "admin") ...[
                  const _SectionLabel(label: "ADMINISTRATION"),
                  
                  // Real-Time System Alerts
                  ListTile(
                    leading: Stack(
                      children: [
                        const Icon(Icons.notifications_active, color: Colors.blueGrey),
                        if (hasUnreadAlerts)
                          Positioned(
                            right: 0,
                            top: 0,
                            child: Container(
                              padding: const EdgeInsets.all(3),
                              decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle),
                              child: Text('${combinedAlerts.length}', style: const TextStyle(fontSize: 8, color: Colors.white, fontWeight: FontWeight.bold)),
                            ),
                          )
                      ],
                    ),
                    title: const Text("System Alerts"),
                    trailing: hasUnreadAlerts ? const Icon(Icons.circle, color: Colors.red, size: 12) : null,
                    onTap: () {
                      if (combinedAlerts.isEmpty) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("No new critical alerts.")));
                      } else {
                        _showSystemAlertsDialog(context);
                      }
                    },
                  ),
                  
                  // Glove Assignment
                  ListTile(
                    leading: const Icon(Icons.bluetooth_connected, color: Colors.blueGrey),
                    title: const Text("Assign Glove Access"),
                    onTap: () => _showAssignGloveDialog(context),
                  ),
                  
                  // Community Management
                  ListTile(
                    leading: const Icon(Icons.location_city, color: Colors.blueGrey),
                    title: const Text("Manage Communities"),
                    onTap: () => _showAssignCommunityDialog(context),
                  ),
                  
                  // Pickups (Redirects to Dashboard)
                  ListTile(
                    leading: const Icon(Icons.local_shipping, color: Colors.blueGrey),
                    title: const Text("Pickup Requests"),
                    onTap: () {
                      Navigator.pop(context); 
                      Navigator.pushReplacementNamed(context, "/adminDashboard");
                    }
                  ),
                  
                  // Stats (Redirects to Dashboard)
                  ListTile(
                    leading: const Icon(Icons.bar_chart, color: Colors.blueGrey),
                    title: const Text("System Stats"),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushReplacementNamed(context, "/adminDashboard");
                    }
                  ),
                ],

                // -----------------------------
                // ♻️ CITIZEN SECTION
                // -----------------------------
                if (_userRole != "admin") ...[
                  ListTile(
                    leading: const Icon(Icons.history_rounded),
                    title: const Text("Dump History"),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, "/history");
                    }
                  ),
                  
                  // 🟢 Community Impact (Dynamic Access)
                  if (communityName != null && communityName.isNotEmpty) ...[
                    const Divider(),
                    _SectionLabel(label: "COMMUNITY: ${communityName.toUpperCase()}"),
                    ListTile(
                      leading: const Icon(Icons.groups, color: Colors.purple),
                      title: const Text("Community Impact"),
                      subtitle: const Text("Pool points for rewards"),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, "/community");
                      },
                    ),
                  ],

                  const Divider(),
                  const _SectionLabel(label: "HEALTHCARE"),
                  
                  // Rehab Game
                  ListTile(
                    leading: Icon(
                      isGameActive ? Icons.sports_esports : Icons.lock,
                      color: isGameActive ? Colors.green : (canAfford ? Colors.orange : Colors.grey),
                    ),
                    title: Text(isGameActive ? "Play Rehab Game" : "Unlock Rehab Glove"),
                    subtitle: Text(isGameActive ? "Expires: ${expiryDate.toString().split(' ')[0]}" : "Costs 100 Points"),
                    onTap: () {
                      if (isGameActive) {
                        Navigator.pop(context);
                        Navigator.pushNamed(context, "/rehabGame", arguments: savedLevel);
                      } else if (canAfford) {
                        _handleRedemption();
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Deposit E-Waste to earn 100 points!")));
                      }
                    },
                  ),
                  
                  // Redemption History
                  ListTile(
                    leading: const Icon(Icons.receipt_long, color: Colors.blueGrey),
                    title: const Text("Redemption History"),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, "/redemptionHistory");
                    }
                  ),
                ],
              ],
            ),
          ),

          const Divider(),
          // ==============================
          // 3. FOOTER
          // ==============================
          ListTile(
            leading: const Icon(Icons.settings_outlined),
            title: const Text("Settings"),
            onTap: () {
              Navigator.pop(context);
              Navigator.pushNamed(context, "/settings");
            }
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}

// 🏷️ Simple Helper for Section Labels
class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 16, top: 12, bottom: 8),
      child: Text(
        label, 
        style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontSize: 12)
      ),
    );
  }
}
import 'dart:convert'; // 🟢 Required for decoding the QR JSON
import 'dart:io'; // 🟢 Required for Platform checking in reassemble()
import 'package:flutter/material.dart';
import 'package:qr_code_scanner_plus/qr_code_scanner_plus.dart'; // 🟢 The new scanner
// ⚠️ Update this import to match your actual file structure
import 'package:sewa/screens/drop_status_screen.dart'; 
import '../services/api_service.dart';

class QRScannerWidget extends StatefulWidget {
  const QRScannerWidget({super.key});

  @override
  State<QRScannerWidget> createState() => _QRScannerWidgetState();
}

class _QRScannerWidgetState extends State<QRScannerWidget> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? controller;
  bool isProcessing = false;

  // 🟢 Required for hot reload to work properly with this camera package
  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller?.pauseCamera();
    } else if (Platform.isIOS) {
      controller?.resumeCamera();
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  // 🟢 Initialize the scanner controller
  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    
    // Listen to the scanner stream
    controller.scannedDataStream.listen((scanData) {
      _handleScan(scanData.code);
    });
  }

  Future<void> _handleScan(String? rawCode) async {
  // 🟢 1. Prevent multiple scans while processing or if code is null
  if (isProcessing || rawCode == null || rawCode.isEmpty) return;

  setState(() => isProcessing = true);
  controller?.pauseCamera(); // 🛑 Camera restricted immediately

  String binId = "";
  try {
    final decodedData = jsonDecode(rawCode);
    binId = decodedData["binId"] ?? rawCode; 
  } catch (e) {
    binId = rawCode;
  }

  // 📡 Request the server to unlock the bin
  final Map<String, dynamic> response = await ApiService.requestBinUnlock(binId);

  if (!mounted) return;

  if (response["success"] == true) {
    // ✅ SUCCESS: Navigate to Drop Status
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("🔓 Bin Unlocked!"), backgroundColor: Colors.green),
    );
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => DropStatusScreen(binId: binId)),
    );
  } 
  else if (response["isFull"] == true) {
    // 🛑 BIN IS FULL: Show Alert Dialog directly here
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red),
            SizedBox(width: 10),
            Text("Bin is Full"),
          ],
        ),
        content: Text(response["message"] ?? "This bin has reached its limit."),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Close dialog
              // 🟢 Unrestrict scan: Resume camera and reset state
              setState(() => isProcessing = false);
              controller?.resumeCamera();
            },
            child: const Text("OK", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  } 
  else {
    // ❌ GENERAL ERROR
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(response["message"] ?? "Failed to open bin."),
        backgroundColor: Colors.red,
      ),
    );
    
    // Resume scanning after a short delay
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => isProcessing = false);
        controller?.resumeCamera();
      }
    });
  }
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Scan Bin QR'),
        backgroundColor: Colors.green,
      ),
      body: Stack(
        children: [
          // 🟢 The Live Camera Feed using qr_code_scanner_plus
          QRView(
            key: qrKey,
            onQRViewCreated: _onQRViewCreated,
            formatsAllowed: const [BarcodeFormat.qrcode], // Optimize for QR only
          ),
          
          // 🎯 Viewfinder Overlay
          Center(
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.greenAccent.withOpacity(0.8), width: 4),
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),

          // ⏳ Network Latency Overlay
          if (isProcessing)
            Container(
              color: Colors.black.withOpacity(0.7),
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(color: Colors.greenAccent),
                    SizedBox(height: 16),
                    Text(
                      "Communicating with Bin...",
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w500),
                    )
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
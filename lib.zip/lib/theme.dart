import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// 🎨 Brand Colors
const Color primaryGreen = Color(0xFF2E7D32);
const Color darkGreen = Color(0xFF1B5E20);
const Color lightGreen = Color(0xFF66BB6A);

// 🔵 Admin Branding Colors
const Color adminColor = Color(0xFF455A64); // Blue-Grey for Admin Portal
const Color adminDark = Color(0xFF263238);

/// ☀️ LIGHT ECO THEME
ThemeData lightTheme = ThemeData(
  useMaterial3: true, // 🟢 Enabled for modern components
  brightness: Brightness.light,
  scaffoldBackgroundColor: const Color(0xFFF8F9FA),
  primaryColor: primaryGreen,
  textTheme: GoogleFonts.poppinsTextTheme(), 
  
  appBarTheme: AppBarTheme(
    titleTextStyle: GoogleFonts.poppins(
        fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white),
    backgroundColor: primaryGreen,
    foregroundColor: Colors.white,
    centerTitle: true,
    elevation: 0,
  ),

  cardTheme: CardTheme(
    color: Colors.white,
    elevation: 2,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  ),

  colorScheme: ColorScheme.fromSeed(
    seedColor: primaryGreen,
    primary: primaryGreen,
    secondary: lightGreen,
    surface: Colors.white,
  ),

  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: primaryGreen,
      foregroundColor: Colors.white,
      textStyle: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 14),
    ),
  ),
);

/// 🌙 DARK ECO THEME
ThemeData darkTheme = ThemeData(
  useMaterial3: true, // 🟢 Enabled for modern components
  brightness: Brightness.dark,
  scaffoldBackgroundColor: const Color(0xFF121212),
  primaryColor: primaryGreen,
  
  textTheme: GoogleFonts.poppinsTextTheme(
    ThemeData(brightness: Brightness.dark).textTheme,
  ),

  appBarTheme: AppBarTheme(
    titleTextStyle: GoogleFonts.poppins(
        fontSize: 20, fontWeight: FontWeight.w600, color: Colors.white),
    backgroundColor: const Color(0xFF1F1F1F), // Slightly lighter than scaffold
    foregroundColor: Colors.white,
    centerTitle: true,
    elevation: 0,
  ),

  // 🟢 Improved Dark Card styling
  cardTheme: CardTheme(
    color: const Color(0xFF1E1E1E),
    elevation: 4,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
  ),

  colorScheme: const ColorScheme.dark(
    primary: primaryGreen,
    secondary: lightGreen,
    surface: Color(0xFF1E1E1E),
    onSurface: Colors.white,
  ),

  elevatedButtonTheme: ElevatedButtonThemeData(
    style: ElevatedButton.styleFrom(
      backgroundColor: primaryGreen,
      foregroundColor: Colors.white,
      textStyle: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.w600),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 14),
    ),
  ),
);
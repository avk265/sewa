import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:sewa/services/api_service.dart';
import 'package:sewa/theme.dart'; // Import brand colors
import 'package:url_launcher/url_launcher.dart';

class NearestBinsScreen extends StatefulWidget {
  const NearestBinsScreen({super.key});

  @override
  State<NearestBinsScreen> createState() => _NearestBinsScreenState();
}

class _NearestBinsScreenState extends State<NearestBinsScreen> {
  Map<String, dynamic>? nearest;
  bool loading = true;
  Position? userPos;

  @override
  void initState() {
    super.initState();
    loadNearest();
  }

  Future<bool> checkPermission() async {
    bool service = await Geolocator.isLocationServiceEnabled();
    if (!service) return false;

    LocationPermission p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) {
      p = await Geolocator.requestPermission();
      if (p == LocationPermission.denied) return false;
    }
    return !(p == LocationPermission.deniedForever);
  }

  Future<void> loadNearest() async {
    bool ok = await checkPermission();
    if (!ok) {
      if (mounted) setState(() => loading = false);
      return;
    }

    try {
      userPos = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high,
      );
      
      // Fetch nearby bins from Cloud API
      List bins = await ApiService.getNearestBins(userPos!.latitude, userPos!.longitude);

      if (bins.isNotEmpty && mounted) {
        setState(() {
          nearest = bins.first;
          loading = false;
        });
      } else {
        if (mounted) setState(() => loading = false);
      }
    } catch (e) {
      if (mounted) setState(() => loading = false);
    }
  }

  Color levelColor(int fill) {
    if (fill < 40) return Colors.green;
    if (fill < 85) return Colors.orange;
    return Colors.red;
  }

  /// 🚗 Open Native Navigation
  Future<void> navigate(double lat, double lng) async {
    // 🟢 FIXED: Proper Universal Google Maps deep link
    final String googleMapsUrl = "https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving";
    final Uri url = Uri.parse(googleMapsUrl);
    
    try {
      if (await canLaunchUrl(url)) {
        await launchUrl(url, mode: LaunchMode.externalApplication);
      } else {
        throw "Could not launch Maps";
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Could not open maps application."), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Nearest SEWA Bin"),
        backgroundColor: primaryGreen,
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator(color: primaryGreen))
          : nearest == null
              ? _buildEmptyState()
              : _buildNearestCard(),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.location_off_outlined, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text("No bins found nearby 😕", style: TextStyle(fontSize: 18, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildNearestCard() {
    double bLat = double.tryParse(nearest!["lat"].toString()) ?? 0.0;
    double bLng = double.tryParse(nearest!["lng"].toString()) ?? 0.0;

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Card(
              elevation: 8,
              shadowColor: primaryGreen.withOpacity(0.2),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 40,
                      backgroundColor: levelColor(nearest!["fillLevel"] ?? 0).withOpacity(0.1),
                      child: Icon(Icons.delete_outline_rounded, 
                           size: 45, 
                           color: levelColor(nearest!["fillLevel"] ?? 0)),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      nearest!["name"] ?? "Smart Bin",
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 8),
                    Text("📍 ${nearest!["distanceKm"] ?? '0.0'} km away",
                        style: TextStyle(fontSize: 17, color: Colors.grey[600], fontWeight: FontWeight.w500)),
                    const SizedBox(height: 20),
                    _buildFillLevelIndicator(),
                    const SizedBox(height: 30),
                    
                    // Main Action: Navigate
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          backgroundColor: primaryGreen,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                        ),
                        onPressed: () => navigate(bLat, bLng),
                        icon: const Icon(Icons.navigation_rounded, color: Colors.white),
                        label: const Text("Start Navigation", 
                             style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    
                    // Secondary Action: View on Map
                    TextButton.icon(
                      onPressed: () => Navigator.pushNamed(context, "/mapBins", arguments: nearest),
                      icon: const Icon(Icons.map_outlined, color: primaryGreen),
                      label: const Text("View on Live Map", style: TextStyle(color: primaryGreen, fontWeight: FontWeight.w600)),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFillLevelIndicator() {
    int fill = nearest!["fillLevel"] ?? 0;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: levelColor(fill).withOpacity(0.05),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: levelColor(fill).withOpacity(0.3))
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text("♻️ Status: ", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
          Text("$fill% Full", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: levelColor(fill))),
        ],
      ),
    );
  }
}
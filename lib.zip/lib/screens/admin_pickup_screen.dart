import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class AdminPickupScreen extends StatefulWidget {
  const AdminPickupScreen({super.key});

  @override
  State<AdminPickupScreen> createState() => _AdminPickupScreenState();
}

class _AdminPickupScreenState extends State<AdminPickupScreen> {
  late Future<List<dynamic>> _pickupRequests;

  @override
  void initState() {
    super.initState();
    _loadRequests();
  }

  // 🟢 Fetch all bins and filter for ones >= 90% full
  void _loadRequests() {
    setState(() {
      _pickupRequests = fetchFullBins();
    });
  }

  Future<List<dynamic>> fetchFullBins() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token') ?? '';

    final response = await http.get(
      Uri.parse('${ApiService.baseUrl}/bins/map'),
      headers: {'Authorization': 'Bearer $token'},
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final List<dynamic> allBins = data['bins'] ?? [];
      
      // Filter logic: Only show bins where currentWeight is 90% or more of maxCapacity
      return allBins.where((bin) {
        final currentWeight = (bin['currentWeight'] ?? 0).toDouble();
        final maxCapacity = (bin['maxCapacity'] ?? 10).toDouble();
        return (currentWeight / maxCapacity) >= 0.90; 
      }).toList();
    } else {
      throw Exception('Failed to load bins');
    }
  }

  Future<void> _handlePickup(String binId) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('auth_token') ?? '';

    // 🟢 Call the new server route to reset the bin weight
    final response = await http.post(
      Uri.parse('${ApiService.baseUrl}/admin/empty-bin'),
      headers: {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({'binId': binId}),
    );
    
    if (!mounted) return;
    
    if (response.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("✅ Bin $binId marked as empty!"),
          backgroundColor: Colors.green,
        ),
      );
      // Reload the list to remove the picked bin
      _loadRequests();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("❌ Failed to empty bin. Try again."),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Pickup Requests"),
        backgroundColor: Colors.red.shade800,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadRequests, // Manual refresh button
          )
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: _pickupRequests,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.red));
          }
          if (snapshot.hasError) {
            return const Center(child: Text("Error loading data. Check server connection."));
          }

          final bins = snapshot.data ?? [];

          if (bins.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.check_circle, size: 80, color: Colors.green.shade300),
                  const SizedBox(height: 16),
                  const Text(
                    "All bins are clean!",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const Text("No pickups needed right now.", style: TextStyle(color: Colors.grey)),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: bins.length,
            itemBuilder: (_, i) {
              final bin = bins[i];
              
              final binId = bin['binId'] ?? 'Unknown';
              final name = bin['name'] ?? "Smart Bin";
              final currentWeight = (bin['currentWeight'] ?? 0).toDouble();
              final maxCapacity = (bin['maxCapacity'] ?? 10).toDouble();
              final fillPercentage = ((currentWeight / maxCapacity) * 100).toStringAsFixed(1);

              return Card(
                elevation: 3,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: const BorderSide(color: Colors.red, width: 1.5) // Highlight full bins in red
                ),
                child: ListTile(
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  leading: const CircleAvatar(
                    backgroundColor: Colors.redAccent,
                    child: Icon(Icons.delete_sweep, color: Colors.white),
                  ),
                  title: Text("$name", style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text("🚨 Fill Level: $fillPercentage% ($currentWeight kg)\nID: $binId", style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
                  trailing: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))
                    ),
                    onPressed: () => _handlePickup(binId),
                    child: const Text("Mark Picked", style: TextStyle(color: Colors.white)),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
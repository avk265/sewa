import 'package:flutter/material.dart';
import 'package:sewa/services/api_service.dart';
import 'package:intl/intl.dart'; 
import 'package:sewa/theme.dart'; // Use your primaryGreen

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<dynamic> dumpHistory = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchHistory();
  }

  // 📡 Fetches the unified history and filters for e-waste deposits
  void _fetchHistory() async {
    final res = await ApiService.getProfile();
    
    if (mounted) {
      if (res["success"] == true) {
        setState(() {
          // 🟢 NEW LOGIC: Filter the main history list for DEPOSIT types
          List<dynamic> allActivity = res["history"] ?? [];
          
          dumpHistory = allActivity
              .where((activity) => activity["type"] == "DEPOSIT")
              .toList();
              
          _isLoading = false;
        });
      } else {
        setState(() => _isLoading = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Unable to sync history")),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Dump History"),
        backgroundColor: primaryGreen,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator(color: primaryGreen))
          : dumpHistory.isEmpty
              ? _buildEmptyState()
              : ListView.builder(
                  padding: const EdgeInsets.all(15),
                  itemCount: dumpHistory.length,
                  itemBuilder: (context, index) {
                    final item = dumpHistory[index];
                    return _buildHistoryCard(item);
                  },
                ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.history_toggle_off, size: 80, color: Colors.grey[400]),
          const SizedBox(height: 15),
          const Text("No deposits found yet!", 
            style: TextStyle(fontSize: 18, color: Colors.grey, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          const Text("Go scan a bin at TKM to start recycling.", style: TextStyle(color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> item) {
    String formattedDate = "Unknown Date";
    if (item["date"] != null) {
      try {
        DateTime dt = DateTime.parse(item["date"]).toLocal();
        formattedDate = DateFormat('dd MMM yyyy, hh:mm a').format(dt);
      } catch (e) {
        formattedDate = "Date error";
      }
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      elevation: 1,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            // Icon section
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: primaryGreen.withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.auto_delete_outlined, color: primaryGreen),
            ),
            const SizedBox(width: 15),
            
            // Detail section
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item["actionDetail"] ?? "E-Waste Deposit",
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                  Text(
                    formattedDate,
                    style: TextStyle(color: Colors.grey[600], fontSize: 13),
                  ),
                  const SizedBox(height: 8),
                  // Displaying weight from the activity log
                  Text(
                    "Weight: ${item["weight"]?.toString() ?? '0'} kg",
                    style: TextStyle(color: primaryGreen, fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                ],
              ),
            ),
            
            // Points section
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  "+${item["points"] ?? 0}",
                  style: const TextStyle(
                    color: primaryGreen,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const Text("pts", style: TextStyle(color: primaryGreen, fontSize: 12, fontWeight: FontWeight.bold)),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
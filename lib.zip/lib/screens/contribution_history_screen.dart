import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/api_service.dart';

// ... imports (keep existing)

class ContributionHistoryScreen extends StatelessWidget {
  const ContributionHistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Contributions"),
        backgroundColor: Colors.green.shade800,
        elevation: 0,
      ),
      body: FutureBuilder(
        // 🟢 CHANGED: Use the dedicated history fetcher
        future: ApiService.getUserHistory(), 
        builder: (context, AsyncSnapshot snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.green));
          }
          
          if (snapshot.hasError || snapshot.data == null || snapshot.data["success"] != true) {
            return const Center(child: Text("Failed to load history."));
          }

          // 🟢 CHANGED: Data is now at snapshot.data["history"] directly
          final List history = snapshot.data["history"] ?? [];

          if (history.isEmpty) {
            return _buildEmptyState();
          }

          return ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: history.length,
            itemBuilder: (_, i) {
              final item = history[i];
              
              // 🟢 Schema Mapping Check:
              // Ensure these keys match your UserActivity schema exactly
              final double weight = (item['weight'] ?? 0).toDouble();
              final String binId = item['binId'] ?? "Unknown Bin";
              
              // Handle optional action details (e.g., "Smartphone Deposit")
              final String title = item['actionDetail'] ?? "$weight kg Recycled";
              
              // Calculate points (match server logic: 10/kg or item based)
              final dynamic points = item['points'] ?? 0;
              
              String formattedDate = "Unknown Date";
              if (item['date'] != null) {
                DateTime parsedDate = DateTime.parse(item['date']);
                formattedDate = DateFormat('MMM dd, yyyy • hh:mm a').format(parsedDate);
              }

              return Card(
                elevation: 1,
                margin: const EdgeInsets.only(bottom: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Colors.green,
                    child: Icon(Icons.eco, color: Colors.white),
                  ),
                  title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text("📍 Bin: $binId\n🕒 $formattedDate"),
                  trailing: Text(
                    "+$points pts",
                    style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 16),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.history_outlined, size: 80, color: Colors.grey),
          SizedBox(height: 16),
          Text("No activities found", style: TextStyle(fontSize: 18, color: Colors.grey)),
        ],
      ),
    );
  }
}
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:qr_code_scanner_plus/qr_code_scanner_plus.dart';
import 'package:sewa/services/api_service.dart';
import 'package:sewa/theme.dart';

class ItemScannerScreen extends StatefulWidget {
  const ItemScannerScreen({super.key});

  @override
  State<ItemScannerScreen> createState() => _ItemScannerScreenState();
}

class _ItemScannerScreenState extends State<ItemScannerScreen> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  QRViewController? controller;
  bool isProcessing = false;

  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller?.pauseCamera();
    } else if (Platform.isIOS) {
      controller?.resumeCamera();
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      _handleScan(scanData.code);
    });
  }

  Future<void> _handleScan(String? rawCode) async {
    if (isProcessing || rawCode == null || rawCode.isEmpty) return;

    setState(() => isProcessing = true);
    controller?.pauseCamera();

    String binId = "";
    try {
      final decodedData = jsonDecode(rawCode);
      binId = decodedData["binId"] ?? rawCode; 
    } catch (e) {
      binId = rawCode;
    }

    // Call the API
    final Map<String, dynamic> response = await ApiService.requestBinUnlock(binId);

    if (!mounted) return;

    if (response['isFull'] == true) {
      // 🛑 SHOW PLAIN TEXT DIALOG
      _showFullBinDialog(response['message']);
    } else if (response['success'] == true) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("✅ Bin Unlocked!"), backgroundColor: Colors.green),
      );
      Navigator.pop(context); 
    } else {
      _showError(response['message'] ?? "❌ Failed to unlock bin.");
    }
  }

  void _showFullBinDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.red),
            SizedBox(width: 10),
            Text("Bin is Full"),
          ],
        ),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              if (mounted) {
                setState(() => isProcessing = false);
                controller?.resumeCamera();
              }
            },
            child: const Text("OK", style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() => isProcessing = false);
        controller?.resumeCamera();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Unlock Smart Bin"), backgroundColor: primaryGreen),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                height: 300,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.black, 
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: primaryGreen.withOpacity(0.5), width: 2),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(22),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      QRView(
                        key: qrKey,
                        onQRViewCreated: _onQRViewCreated,
                        formatsAllowed: const [BarcodeFormat.qrcode], 
                      ),
                      Positioned(top: 20, left: 20, child: _corner(0)),
                      Positioned(top: 20, right: 20, child: _corner(1)),
                      Positioned(bottom: 20, left: 20, child: _corner(3)), // Fixed
                      Positioned(bottom: 20, right: 20, child: _corner(2)), // Fixed

                      if (isProcessing)
                        const Center(child: CircularProgressIndicator(color: Colors.white)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 40),
              const Text("Scan Bin QR Code", style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text(
                "Point your camera at the QR code displayed on the SEWA bin.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: primaryGreen,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: () => controller?.toggleFlash(),
                  icon: const Icon(Icons.flash_on, color: Colors.white),
                  label: const Text("Toggle Flashlight", style: TextStyle(color: Colors.white)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _corner(int rotationMultiplier) {
    return RotatedBox(
      quarterTurns: rotationMultiplier,
      child: Container(
        width: 40, height: 40,
        decoration: BoxDecoration(
          border: Border(
            top: BorderSide(color: primaryGreen, width: 4),
            left: BorderSide(color: primaryGreen, width: 4),
          ),
        ),
      ),
    );
  }
}
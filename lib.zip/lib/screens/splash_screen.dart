import 'package:flutter/material.dart';
import 'package:sewa/theme.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/api_service.dart';

class SplashScreen extends StatefulWidget {
  final Function toggleTheme; 

  const SplashScreen({super.key, required this.toggleTheme});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuthAndNavigate();
  }

  // 🔐 Check Authentication Status & Route based on Role
  Future<void> _checkAuthAndNavigate() async {
    // 1. Branding visibility delay
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    // 2. Fetch locally saved credentials
    var sharedPreferences = await SharedPreferences.getInstance();
    SharedPreferences prefs = sharedPreferences;
    String? token = prefs.getString("token");
    String? savedRole = prefs.getString("user_role"); // 🟢 New: Pull local role

    // No token -> Immediate Login
    if (token == null) {
      Navigator.pushReplacementNamed(context, "/login");
      return;
    }

    // 3. Token exists! Verify with server
    // Note: getProfile now returns {success, user, history}
    final res = await ApiService.getProfile();
    
    if (!mounted) return;

    if (res["success"] == true && res["user"] != null) {
      // ✅ Token is valid. 
      // Use the server-provided role for ultimate accuracy
      String role = res["user"]["role"] ?? savedRole ?? "user";

      if (role == "admin") {
        Navigator.pushReplacementNamed(context, "/adminDashboard");
      } else {
        Navigator.pushReplacementNamed(context, "/dashboard");
      }
    } else {
      // ❌ Token is expired, invalid, or server is unreachable
      // If server is unreachable but we have a token, we could potentially let them in 
      // (offline mode), but for SEWA security, we force a re-login.
      await ApiService.logout();
      if (mounted) {
        Navigator.pushReplacementNamed(context, "/login");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: primaryGreen,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: const [
            Icon(Icons.recycling, size: 120, color: Colors.white),
            SizedBox(height: 16),
            Text(
              "SEWA",
              style: TextStyle(
                fontSize: 42, 
                fontWeight: FontWeight.bold, 
                color: Colors.white,
                letterSpacing: 2.0
              ),
            ),
            SizedBox(height: 8),
            Text(
              "Smart E-Waste Management",
              style: TextStyle(
                fontSize: 16, 
                color: Colors.white70,
                fontWeight: FontWeight.w500
              ),
            ),
            SizedBox(height: 50),
            
            // Loading indicator while verifying session
            CircularProgressIndicator(color: Colors.white),
          ],
        ),
      ),
    );
  }
}
import 'package:flutter/material.dart';
import 'package:sewa/services/api_service.dart';

class CommunityImpactScreen extends StatefulWidget {
  const CommunityImpactScreen({super.key});

  @override
  State<CommunityImpactScreen> createState() => _CommunityImpactScreenState();
}

class _CommunityImpactScreenState extends State<CommunityImpactScreen> {
  List campaigns = [];
  int userBalance = 0;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchCampaigns();
  }

  Future<void> _fetchCampaigns() async {
    final res = await ApiService.getCommunityCampaigns();
    if (res["success"] == true && mounted) {
      setState(() {
        campaigns = res["campaigns"];
        userBalance = res["userBalance"];
        isLoading = false;
      });
    }
  }

  // 🟢 Dynamic Donation Slider Bottom Sheet
  void _openDonationSheet(Map campaign) {
    double donationAmount = 10; // Default min

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("Donate to ${campaign['title']}", style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 10),
                  Text("Your Balance: $userBalance pts", style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  
                  Text("${donationAmount.toInt()} pts", style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
                  Slider(
                    value: donationAmount,
                    min: 10,
                    max: userBalance < 10 ? 10 : userBalance.toDouble(),
                    divisions: userBalance < 10 ? 1 : (userBalance / 10).toInt(),
                    activeColor: Colors.green,
                    onChanged: userBalance < 10 ? null : (val) => setSheetState(() => donationAmount = val),
                  ),
                  
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 14)),
                      onPressed: userBalance < 10 ? null : () async {
                        Navigator.pop(context);
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Processing donation...")));
                        final res = await ApiService.donateToCampaign(campaign['_id'], donationAmount.toInt());
                        if (res['success'] == true) {
                          _fetchCampaigns(); // Refresh data
                          if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Thank you for your contribution!"), backgroundColor: Colors.green));
                        }
                      },
                      child: const Text("Confirm Donation"),
                    ),
                  )
                ],
              ),
            );
          }
        );
      }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Community Impact"), backgroundColor: Colors.purple.shade700, foregroundColor: Colors.white),
      body: isLoading 
        ? const Center(child: CircularProgressIndicator())
        : campaigns.isEmpty 
          ? const Center(child: Text("No active campaigns for your community yet."))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: campaigns.length,
              itemBuilder: (context, index) {
                final campaign = campaigns[index];
                final double progress = campaign['raisedPoints'] / campaign['targetPoints'];

                return Card(
                  margin: const EdgeInsets.only(bottom: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: Colors.purple.shade100, borderRadius: BorderRadius.circular(12)),
                          child: Text(campaign['type'] == 'RAFFLE' ? "🎟️ RAFFLE" : "🌍 COMMUNITY GOAL", style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.purple.shade800)),
                        ),
                        const SizedBox(height: 12),
                        Text(campaign['title'], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text(campaign['description'], style: const TextStyle(color: Colors.grey)),
                        const SizedBox(height: 16),
                        LinearProgressIndicator(value: progress.clamp(0.0, 1.0), backgroundColor: Colors.grey.shade300, color: Colors.purple, minHeight: 10, borderRadius: BorderRadius.circular(5)),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("${campaign['raisedPoints']} / ${campaign['targetPoints']} pts", style: const TextStyle(fontWeight: FontWeight.bold)),
                            Text("${(progress * 100).toInt()}% Funded", style: TextStyle(color: Colors.purple.shade700, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.purple.shade500, foregroundColor: Colors.white),
                            onPressed: () => _openDonationSheet(campaign),
                            child: const Text("Donate Points"),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
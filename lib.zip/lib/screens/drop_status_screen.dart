// lib/screens/drop_status_screen.dart

import 'package:flutter/material.dart';
import '../services/api_service.dart';

class DropStatusScreen extends StatefulWidget {
  final String binId;
  const DropStatusScreen({super.key, required this.binId});

  @override
  State<DropStatusScreen> createState() => _DropStatusScreenState();
}

class _DropStatusScreenState extends State<DropStatusScreen> {
  bool isProcessing = true;
  Map<String, dynamic>? result;

  @override
  void initState() {
    super.initState();
    _waitForHardware();
  }

  Future<void> _waitForHardware() async {
    // We wait 5 seconds for the IoT simulator to finish weighing and posting to the server
    await Future.delayed(const Duration(seconds: 5));
    
    // 🟢 FETCH UPDATED DATA
    // Note: The latest server update sends history as a separate list in the profile response
    final res = await ApiService.getProfile(); 
    
    if (mounted && res["success"]) {
      setState(() {
        // 🟢 UPDATE: Pulling from the new separated history list 
        // which contains the latest UserActivity documents
        List<dynamic> history = res["history"] ?? [];
        
        if (history.isNotEmpty) {
          result = history.first; // This is the DEPOSIT activity we just created
        }
        
        isProcessing = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // 🟢 New dynamic color based on the theme we discussed
    const primaryGreen = Color(0xFF2E7D32);

    return Scaffold(
      body: Container(
        width: double.infinity,
        color: Colors.white,
        child: Center(
          child: isProcessing 
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(color: primaryGreen, strokeWidth: 5),
                  const SizedBox(height: 30),
                  Text(
                    "Bin ${widget.binId} is open", 
                    style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: primaryGreen)
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Please drop your items and close the lid.",
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                  const SizedBox(height: 5),
                  const Text("The bin is currently weighing your waste...", style: TextStyle(fontStyle: FontStyle.italic)),
                ],
              )
            : Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.check_circle, color: primaryGreen, size: 120),
                  const SizedBox(height: 20),
                  const Text(
                    "Waste Secured!", 
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Colors.black87)
                  ),
                  const SizedBox(height: 20),
                  
                  // 🟢 UI UPDATE: Showing details from the new UserActivity model
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: Colors.green.shade50,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Column(
                      children: [
                        Text(
                          "Item: ${result?['itemName'] ?? 'Hardware'}",
                          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Measured Weight: ${result?['weight'] ?? '0.0'} kg",
                          style: const TextStyle(fontSize: 18),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          "Points Earned: +${result?['points'] ?? '0'}",
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: primaryGreen),
                        ),
                      ],
                    ),
                  ),
                  
                  const SizedBox(height: 40),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: primaryGreen,
                      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () => Navigator.pushReplacementNamed(context, "/dashboard"),
                    child: const Text(
                      "Back to Dashboard", 
                      style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)
                    ),
                  )
                ],
              ),
        ),
      ),
    );
  }
}
// 🟢 OPTIMIZED: RehabGameScreen.dart 
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO; 
import 'package:sewa/services/api_service.dart';

class RehabGameScreen extends StatefulWidget {
  final int startingLevel;
  const RehabGameScreen({super.key, required this.startingLevel});

  @override
  State<RehabGameScreen> createState() => _RehabGameScreenState();
}

class _RehabGameScreenState extends State<RehabGameScreen> {
  IO.Socket? socket; 
  int currentLevel = 1;
  bool isConnected = false; 
  bool _isHardwareValidated = false; 
  String? _assignedGloveId;
  String _uiMessage = "Verifying Glove ID...";
  
  // Sensor Data
// Sensor Data
  int thumb = 0, indexFinger = 0, middle = 0, ring = 0, pinky = 0;
  int ax = 0, ay = 0, az = 0;

  // 🟢 ADD THIS: The master calibration variable for used flex sensors
  int passThreshold = 40;

  @override
  void initState() {
    super.initState();
    currentLevel = widget.startingLevel;
    _initGatekeeper(); 
  }
  
  Future<void> _initGatekeeper() async {
    try {
      final res = await ApiService.getProfile();
      if (res["success"] == true && res["user"]["gloveId"] != null) {
        setState(() {
          _assignedGloveId = res["user"]["gloveId"];
          _uiMessage = "Waiting for $_assignedGloveId to connect...";
        });
        _connectToSocketBridge(); 
      } else {
        setState(() => _uiMessage = "Access Denied: No Glove ID registered.");
      }
    } catch (e) {
      setState(() => _uiMessage = "Network error verifying ID.");
    }
  }

  void _connectToSocketBridge() {
  debugPrint("🌐 Attempting to connect to: ${ApiService.baseUrl}");
  
  socket = IO.io(ApiService.baseUrl, <String, dynamic>{
    'transports': ['polling','websocket'],
    'autoConnect': true,
    'forceNew': true,
    // 🟢 ADD THIS: Give the server 60 seconds to wake up before timing out
    'timeout': 60000, 
  });

  socket!.onConnect((_) {
    debugPrint("✅ CLOUD CONNECTED: Bridge is active.");
    if (mounted) setState(() => isConnected = true);
  });

  socket!.onConnectError((err) => debugPrint("❌ NETWORK ERROR: $err"));

  // 🟢 THE LISTENER: Matches the Server's 'rehab-game-sync'
  socket!.on('rehab-game-sync', (data) {
    if (!mounted) return;

    // 🕵️ DEBUG LOG 1: See what the server is actually shouting
    debugPrint("📡 SERVER SHOUT RECEIVED: $data");

    // 1. Check for basic keys
    if (data["protocol"] != "SEWA_GLOVE_V1") {
      debugPrint("⚠️ PROTOCOL MISMATCH: Expected SEWA_GLOVE_V1, got ${data['protocol']}");
      return;
    }

    // 2. Identity Check (The "Gatekeeper")
    String incomingId = (data["deviceId"] ?? "").toString().trim().toUpperCase();
    String expectedId = (_assignedGloveId ?? "").trim().toUpperCase();

    debugPrint("🆔 ID CHECK: Incoming [$incomingId] vs Expected [$expectedId]");

    if (incomingId == expectedId) {
      debugPrint("🎯 MATCH FOUND! Unlocking UI...");
      setState(() {
        _isHardwareValidated = true; 
        _uiMessage = "Glove Connected!";
        
        // Mapping sensors from Arduino JSON
        thumb = data["t"] ?? 0;
        indexFinger = data["i"] ?? 0;
        middle = data["m"] ?? 0;
        ring = data["r"] ?? 0;
        pinky = data["p"] ?? 0;
        
        // Mapping IMU
        ax = data["ax"] ?? 0;
        ay = data["ay"] ?? 0;
        az = data["az"] ?? 0;
      });
      _checkLevelCompletion();
    } else {
      debugPrint("🚫 ACCESS DENIED: This data belongs to a different Glove ID.");
    }
  });

  socket!.onDisconnect((_) {
    debugPrint("🔌 SOCKET DISCONNECTED");
    if (mounted) {
      setState(() {
        isConnected = false;
        _isHardwareValidated = false;
        _uiMessage = "Link Lost. Reconnecting...";
      });
    }
  });
}

  void _checkLevelCompletion() {
    // Level 1: Bend Index Finger
    if (currentLevel == 1 && indexFinger > passThreshold) {
      _levelUp();
    }
    // Level 2: Keep Index bent, now bend Middle Finger
    else if (currentLevel == 2 && indexFinger > passThreshold && middle > passThreshold) {
      _levelUp();
    }
    // Level 3: Keep Index & Middle bent, now bend Ring Finger
    else if (currentLevel == 3 && indexFinger > passThreshold && middle > passThreshold && ring > passThreshold) {
      _levelUp();
    }
    // Level 4: Keep Index, Middle & Ring bent, now bend Pinky
    else if (currentLevel == 4 && indexFinger > passThreshold && middle > passThreshold && ring > passThreshold && pinky > passThreshold) {
      _levelUp();
    }
    // Level 5: Form a full fist (add Thumb)
    else if (currentLevel == 5 && indexFinger > passThreshold && middle > passThreshold && ring > passThreshold && pinky > passThreshold && thumb > passThreshold) {
      _levelUp();
    }
  }

  void _levelUp() async {
    if (currentLevel >= 5) return; 
    setState(() => currentLevel++);
    await ApiService.updateGameLevel(currentLevel); 
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("🎉 Level Up! Advanced to Level $currentLevel"), backgroundColor: Colors.teal)
      );
    }
  }

  @override
  void dispose() {
    socket?.disconnect(); 
    socket?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Therapy Session"), 
        backgroundColor: Colors.teal,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15),
            child: Icon(Icons.circle, size: 12, color: _isHardwareValidated ? Colors.greenAccent : Colors.redAccent),
          )
        ],
      ),
      body: Stack(
        children: [
          Opacity(
            opacity: _isHardwareValidated ? 1.0 : 0.1,
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                children: [
                  _buildLevelHeader(),
                  const SizedBox(height: 25),
                  _buildInstructionCard(),
                  const SizedBox(height: 30),
                  _buildSensorSection("Finger Flexion", [
                    _buildSensorBar("Thumb", thumb, Colors.redAccent),
                    _buildSensorBar("Index", indexFinger, Colors.blueAccent),
                    _buildSensorBar("Middle", middle, Colors.orangeAccent),
                    _buildSensorBar("Ring", ring, Colors.purpleAccent),
                    _buildSensorBar("Pinky", pinky, Colors.pinkAccent),
                  ]),
                  const SizedBox(height: 30),
                  _buildSensorSection("Wrist Orientation", [_buildKinematicsGrid()]),
                ],
              ),
            ),
          ),
          if (!_isHardwareValidated) _buildLockOverlay(),
        ],
      ),
    );
  }

  // --- UI HELPER METHODS ---
  Widget _buildSensorSection(String title, List<Widget> children) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const Divider(),
        ...children,
      ],
    );
  }

  Widget _buildLockOverlay() => Container(
    color: Colors.black87,
    width: double.infinity,
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const CircularProgressIndicator(color: Colors.teal),
        const SizedBox(height: 25),
        Icon(_assignedGloveId == null ? Icons.error_outline : Icons.bluetooth_searching, color: Colors.teal, size: 80),
        const SizedBox(height: 20),
        Text(_uiMessage, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 16)),
      ],
    ),
  );

  Widget _buildLevelHeader() => Container(
    width: double.infinity,
    padding: const EdgeInsets.symmetric(vertical: 20),
    decoration: BoxDecoration(color: Colors.teal, borderRadius: BorderRadius.circular(20)),
    child: Column(
      children: [
        const Text("PROGRESS STATUS", style: TextStyle(color: Colors.white70, fontSize: 12, fontWeight: FontWeight.bold)),
        Text("LEVEL $currentLevel / 5", style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
      ],
    ),
  );

  Widget _buildInstructionCard() {
    String msg = switch (currentLevel) {
      1 => "Task 1: Bend your INDEX finger past $passThreshold%",
      2 => "Task 2: Hold Index, now bend MIDDLE finger",
      3 => "Task 3: Hold Index & Middle, bend RING finger",
      4 => "Task 4: Hold Index, Middle, Ring, bend PINKY",
      5 => "Task 5: Final Step! Bend THUMB to form a full fist",
      _ => "🏆 Session Complete! Data synced to cloud."
    };
    
    return Card(
      color: Colors.teal.shade50, 
      child: Padding(
        padding: const EdgeInsets.all(20), 
        child: Text(
          msg, 
          style: const TextStyle(fontSize: 18, color: Colors.teal, fontWeight: FontWeight.bold), 
          textAlign: TextAlign.center
        )
      )
    );
  }
  Widget _buildSensorBar(String label, int value, Color color) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(
      children: [
        SizedBox(width: 70, child: Text(label)),
        Expanded(child: LinearProgressIndicator(value: (value / 100.0).clamp(0.0, 1.0), color: color, backgroundColor: color.withOpacity(0.1), minHeight: 12, borderRadius: BorderRadius.circular(10))),
        SizedBox(width: 45, child: Text(" $value%", textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold))),
      ],
    ),
  );

  Widget _buildKinematicsGrid() => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: [_buildAxisData("ROLL (X)", ax), _buildAxisData("PITCH (Y)", ay), _buildAxisData("YAW (Z)", az)],
  );

  Widget _buildAxisData(String label, int value) => Column(
    children: [
      Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey, fontWeight: FontWeight.bold)),
      Text("${(value / 1000).toStringAsFixed(1)}k", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal)),
    ],
  );
}
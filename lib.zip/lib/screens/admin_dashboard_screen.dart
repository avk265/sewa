import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import '../services/api_service.dart';
import '../widgets/drawer_menu.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> with SingleTickerProviderStateMixin {
  late IO.Socket socket;
  late TabController _tabController;
  
  // 📊 DATA STATES
  List<Map<String, dynamic>> liveAlerts = []; // Real-time Socket events
  List<dynamic> usersList = [];
  List<dynamic> binsList = [];
  List<dynamic> historicalFeed = []; // Database logs from admin/stats
  bool isLoading = true;

  
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    initSocket(); // 🟢 Socket is initialized here
    _fetchDashboardData();
  }

  // 🔌 1. SOCKET INITIALIZATION
  // Inside your AdminDashboardState
List<String> fullBinAlerts = []; 
void _showTopNotification(String message) {
  if (!mounted) return;

  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: Text(message, style: const TextStyle(fontWeight: FontWeight.bold)),
      backgroundColor: Colors.red.shade900,
      behavior: SnackBarBehavior.floating, // Required for top positioning
      margin: EdgeInsets.only(
        bottom: MediaQuery.of(context).size.height - 150, // Pushes it to the top
        left: 10,
        right: 10,
      ),
      duration: const Duration(seconds: 4),
      action: SnackBarAction(
        label: "VIEW",
        textColor: Colors.white,
        onPressed: () => _tabController.animateTo(2), // Switch to Bins tab
      ),
    ),
  );
}
void initSocket() {
  // 1. Initialize the socket safely
  socket = IO.io(ApiService.baseUrl, <String, dynamic>{
    'transports': ['websocket'],
    'autoConnect': true,
  });

  socket.onConnect((_) {
    debugPrint("✅ Admin Connected to SEWA Notification Bridge");
  });

  // 🟢 2. LISTEN FOR: 'admin-notification'
  socket.on('admin-notification', (data) {
    // Expected data format: { "message": "🚨 Bin BIN001 is Full!", "binId": "BIN001" }
    String msg = data['message'] ?? "Critical Alert Received";
    String binId = data['binId'] ?? "Unknown Bin";

    if (mounted) {
      setState(() {
        // 3. Prevent duplicate alerts in the Drawer/List
        if (!fullBinAlerts.contains(binId)) {
          fullBinAlerts.add(binId);
        }
      });
      
      // 4. Trigger the UI Alert
      _showTopNotification(msg);
      debugPrint("📢 Alert Dispatched: $msg");
    }
  });
}
  // 🌐 2. UNIFIED DATA FETCH
  Future<void> _fetchDashboardData() async {
    final res = await ApiService.getAdminStats();
    if (mounted && res["success"] == true) {
      setState(() {
        usersList = res["users"] ?? [];
        binsList = res["bins"] ?? [];
        historicalFeed = res["feed"] ?? []; // Correctly mapped to 'feed' key from server
        isLoading = false;
      });
    }
  }

  // 🟢 NEW: FUNCTION TO EMPTY BIN
  Future<void> _emptyBin(String binId) async {
    final messenger = ScaffoldMessenger.of(context); // Context safety
    messenger.showSnackBar(SnackBar(content: Text("Emptying Bin $binId...")));
    
    final res = await ApiService.markBinEmpty(binId);
    
    if (res['success'] == true && mounted) {
      messenger.showSnackBar(const SnackBar(content: Text("Bin successfully marked as empty!"), backgroundColor: Colors.green));
      _fetchDashboardData(); // Refresh the lists to show 0%
    } else if (mounted) {
      messenger.showSnackBar(SnackBar(content: Text("Failed: ${res['message']}"), backgroundColor: Colors.red));
    }
  }

  @override
  void dispose() {
    socket.dispose();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      drawer: DrawerMenu(alerts: fullBinAlerts), // restored drawer
      appBar: AppBar(
        automaticallyImplyLeading: false, // removes back arrow
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        title: const Text("SEWA Admin Center"),
        backgroundColor: Colors.red.shade900,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.bolt), text: "Live Feed"),
            Tab(icon: Icon(Icons.people_alt), text: "Users"),
            Tab(icon: Icon(Icons.warehouse), text: "Bins"),
          ],
        ),
      ),
      body: isLoading 
          ? const Center(child: CircularProgressIndicator()) 
          : TabBarView(
              controller: _tabController,
              children: [
                _buildActivityTab(),
                _buildUsersTab(),
                _buildBinsTab(),
              ],
            ),
    );
  }

  // --- TAB 1: INTEGRATED FEED ---
  Widget _buildActivityTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(10),
      itemCount: liveAlerts.length + historicalFeed.length,
      itemBuilder: (context, index) {
        if (index < liveAlerts.length) {
          return _buildFeedItem(liveAlerts[index], isLive: true);
        } else {
          return _buildFeedItem(historicalFeed[index - liveAlerts.length], isLive: false);
        }
      },
    );
  }

  Widget _buildFeedItem(dynamic data, {required bool isLive}) {
    final bool isCritical = data['type'] == 'BIN_FULL' || data['type'] == 'CRITICAL_ALERT'; // 🟢 Added Critical catch
    
    // Server 'populate' makes userId a Map. Socket might just be a String or Map.
    String name = "System";
    if (data['userId'] is Map) {
      name = data['userId']['name'] ?? "User";
    }

    return Card(
      color: isLive ? Colors.red.shade50 : Colors.white,
      margin: const EdgeInsets.only(bottom: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(10),
        side: BorderSide(color: isCritical ? Colors.red : Colors.transparent),
      ),
      child: ListTile(
        leading: Icon(isCritical ? Icons.warning : Icons.eco, color: isCritical ? Colors.red : Colors.green),
        title: Text(data['message'] ?? (data['actionDetail'] ?? "Activity"), 
                    style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("$name • ${isLive ? 'LIVE' : data['date'].toString().substring(0, 10)}"),
        trailing: isLive ? const Badge(label: Text("NEW"), backgroundColor: Colors.red) : null,
      ),
    );
  }

  // --- TAB 2: USER MANAGEMENT ---
  Widget _buildUsersTab() {
    return ListView.builder(
      itemCount: usersList.length,
      itemBuilder: (context, index) {
        final user = usersList[index];
        return ListTile(
          leading: const CircleAvatar(child: Icon(Icons.person)),
          title: Text(user['name'] ?? "Citizen"),
          subtitle: Text(user['email'] ?? ""),
          trailing: Text("${user['greenPoints'] ?? 0} pts", style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
        );
      },
    );
  }

  // --- TAB 3: BIN FLEET ---
  Widget _buildBinsTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: binsList.length,
      itemBuilder: (context, index) {
        final bin = binsList[index];
        final double weight = (bin['currentWeight'] ?? 0).toDouble();
        final double max = (bin['maxCapacity'] ?? 10).toDouble();
        final double fill = (weight / max).clamp(0.0, 1.0);

        return Card(
          child: ListTile(
            title: Text(bin['name'] ?? "Bin ${bin['binId']}"),
            subtitle: LinearProgressIndicator(value: fill, color: fill >= 0.8 ? Colors.red : Colors.green),
            // 🟢 MODIFIED: Wrap the existing text in a Row to add the delete button if full
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("${(fill * 100).toStringAsFixed(0)}%", style: TextStyle(color: fill >= 0.8 ? Colors.red : Colors.green, fontWeight: FontWeight.bold)),
                if (fill >= 0.8) ...[
                  const SizedBox(width: 8),
                  IconButton(
                    icon: const Icon(Icons.delete_sweep, color: Colors.red),
                    tooltip: "Acknowledge Pickup & Empty Bin",
                    onPressed: () => _emptyBin(bin['binId']),
                  ),
                ]
              ],
            ),
          ),
        );
      },
    );
  }
}
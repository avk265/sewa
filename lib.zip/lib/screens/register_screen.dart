import 'package:flutter/material.dart';
import 'package:sewa/theme.dart';
import 'package:sewa/services/api_service.dart';

class RegisterScreen extends StatefulWidget {
  final Function toggleTheme;
  const RegisterScreen({super.key, required this.toggleTheme});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController nameCtrl = TextEditingController();
  final TextEditingController emailCtrl = TextEditingController();
  final TextEditingController mobileCtrl = TextEditingController();
  final TextEditingController addressCtrl = TextEditingController();
  final TextEditingController passCtrl = TextEditingController();

  bool _loading = false;
  bool _showPass = false;
  
  // 🟢 NEW: State to track if we are registering an Admin or Citizen
  bool isAdminRegistration = false; 

  Future<void> registerUser() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _loading = true);

    try {
      // 🟢 UPDATE: Passing the 'role' to the ApiService
      final res = await ApiService.register(
        nameCtrl.text.trim(),
        emailCtrl.text.trim(),
        passCtrl.text.trim(),
        mobileCtrl.text.trim(),
        addressCtrl.text.trim(),
        isAdminRegistration ? "admin" : "user", // Pass role string
      );

      if (!mounted) return;

      if (res["success"] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("✅ Registration Successful! Please login."),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pushReplacementNamed(context, "/login");
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("❌ ${res["message"] ?? "Registration failed"}"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Server error: Check connection."),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _loading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isDark = Theme.of(context).brightness == Brightness.dark;
    
    // 🎨 Dynamic color based on selected role
    final Color activeColor = isAdminRegistration ? Colors.blueGrey : primaryGreen;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Create Account"),
        elevation: 0,
        
      ),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 20),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // 🔄 NEW: Role Toggle for Citizens/Admins
                  Container(
                    decoration: BoxDecoration(
                      color: isDark ? Colors.grey[800] : Colors.grey[200],
                      borderRadius: BorderRadius.circular(30),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _buildToggleButton("Citizen", !isAdminRegistration, Colors.green),
                        _buildToggleButton("Admin", isAdminRegistration, Colors.blueGrey),
                      ],
                    ),
                  ),
                  const SizedBox(height: 30),

                  Icon(
                    isAdminRegistration ? Icons.admin_panel_settings : Icons.person_add_alt_1_rounded, 
                    size: 80, 
                    color: activeColor
                  ),
                  const SizedBox(height: 16),
                  Text(
                    isAdminRegistration ? "Admin Registration" : "Join SEWA",
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : activeColor,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    isAdminRegistration ? "Register an authorized SEWA controller" : "Start your e-waste recycling journey",
                    style: const TextStyle(fontSize: 14, color: Colors.grey),
                  ),
                  const SizedBox(height: 30),

                  _buildTextField(
                    label: "Full Name",
                    icon: Icons.person,
                    controller: nameCtrl,
                    activeColor: activeColor,
                    validator: (v) => v!.isEmpty ? "Enter your name" : null,
                  ),

                  _buildTextField(
                    label: "Email",
                    icon: Icons.email,
                    controller: emailCtrl,
                    activeColor: activeColor,
                    keyboardType: TextInputType.emailAddress,
                    validator: (v) => !v!.contains("@") ? "Enter valid email" : null,
                  ),

                  // Mobile and Address are only mandatory for Citizens, not Admins (optional)
                  _buildTextField(
                    label: "Mobile Number",
                    icon: Icons.phone,
                    controller: mobileCtrl,
                    activeColor: activeColor,
                    keyboardType: TextInputType.phone,
                    validator: (v) => !isAdminRegistration && v!.length < 10 ? "Enter valid phone number" : null,
                  ),

                  _buildTextField(
                    label: "Address / Office Branch",
                    icon: Icons.home,
                    controller: addressCtrl,
                    activeColor: activeColor,
                    maxLines: 2,
                    validator: (v) => !isAdminRegistration && v!.isEmpty ? "Enter your location" : null,
                  ),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 16),
                    child: TextFormField(
                      controller: passCtrl,
                      obscureText: !_showPass,
                      decoration: InputDecoration(
                        labelText: "Password",
                        prefixIcon: Icon(Icons.lock, color: activeColor),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12)
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: activeColor, width: 2),
                          borderRadius: BorderRadius.circular(12)
                        ),
                        suffixIcon: IconButton(
                          icon: Icon(_showPass ? Icons.visibility_off : Icons.visibility),
                          onPressed: () => setState(() => _showPass = !_showPass),
                        ),
                      ),
                      validator: (v) => v!.length < 6 ? "Password must be at least 6 chars" : null,
                    ),
                  ),
                  const SizedBox(height: 10),

                  _loading
                      ? CircularProgressIndicator(color: activeColor)
                      : SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: activeColor,
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
                            ),
                            onPressed: registerUser,
                            child: const Text(
                              "Register", 
                              style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: Colors.white)
                            ),
                          ),
                        ),
                  
                  const SizedBox(height: 10),

                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text("Already have an account?"),
                      TextButton(
                        onPressed: () => Navigator.pushReplacementNamed(context, "/login"),
                        child: Text(
                          "Login here", 
                          style: TextStyle(fontWeight: FontWeight.bold, color: activeColor)
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // 🎛️ NEW: Role Toggle Helper Widget
  Widget _buildToggleButton(String text, bool isSelected, Color activeColor) {
    return GestureDetector(
      onTap: () => setState(() => isAdminRegistration = text == "Admin"),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 12),
        decoration: BoxDecoration(
          color: isSelected ? activeColor : Colors.transparent,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Text(
          text,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: isSelected ? Colors.white : Colors.grey,
          ),
        ),
      ),
    );
  }

  // 🧾 Helper Widget
  Widget _buildTextField({
    required String label,
    required IconData icon,
    required TextEditingController controller,
    required Color activeColor,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
    required String? Function(String?) validator,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: activeColor),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12)
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(color: activeColor, width: 2),
            borderRadius: BorderRadius.circular(12)
          ),
        ),
        validator: validator,
      ),
    );
  }
}
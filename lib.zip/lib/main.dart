import 'package:flutter/material.dart';
import 'package:sewa/theme.dart';

// Core Auth & Navigation
import 'package:sewa/screens/splash_screen.dart';
import 'package:sewa/screens/login_screen.dart';
import 'package:sewa/screens/register_screen.dart';
import 'package:sewa/screens/dashboard_screen.dart';
import 'package:sewa/screens/admin_dashboard_screen.dart';

// User Features
import 'package:sewa/screens/profile_screen.dart';
import 'package:sewa/screens/contribution_history_screen.dart';
import 'package:sewa/screens/map_bins_screen.dart';
import 'package:sewa/screens/nearest_bins_screen.dart';
import 'package:sewa/screens/settings_screen.dart';

// 🟢 NEW: Community Impact Screen
import 'package:sewa/screens/community_impact_screen.dart';

// 🟢 SCANNER & SIMULATOR
import 'package:sewa/screens/scanner_screen.dart'; 

// 🟢 HEALTHCARE & REWARDS
import 'package:sewa/screens/rehab_game_screen.dart';
import 'package:sewa/screens/redemption_history_screen.dart';
import 'package:sewa/screens/drop_status_screen.dart'; 

void main() {
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  // 🌓 Theme State Management
  bool isDark = false;

  void toggleTheme() {
    setState(() {
      isDark = !isDark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: "SEWA Smart E-Waste",
      
      // Applying dynamic theme
      theme: lightTheme,
      darkTheme: darkTheme,
      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,

      // App starts with the Splash Screen to verify session
      home: SplashScreen(toggleTheme: toggleTheme),

      // 🗺️ Application Route Map
      routes: {
        "/login": (c) => LoginScreen(toggleTheme: toggleTheme),
        "/register": (c) => RegisterScreen(toggleTheme: toggleTheme),
        
        "/dashboard": (c) => DashboardScreen(toggleTheme: toggleTheme),
        
        "/profile": (c) => ProfileScreen(toggleTheme: toggleTheme),
        "/history": (c) => const ContributionHistoryScreen(),
        "/mapBins": (c) => const MapBinsScreen(),
        "/nearestBins": (c) => const NearestBinsScreen(),
        "/settings": (c) => SettingsScreen(toggleTheme: toggleTheme, darkMode: isDark),

        // 🟢 NEW: Community Route added here
        "/community": (c) => const CommunityImpactScreen(),

        "/scanner": (c) => const ItemScannerScreen(), 

        "/redemptionHistory": (c) => const RedemptionHistoryScreen(),

        "/dropStatus": (context) {
          final binId = ModalRoute.of(context)?.settings.arguments as String? ?? "Unknown";
          return DropStatusScreen(binId: binId);
        },

        "/rehabGame": (context) {
          final level = ModalRoute.of(context)?.settings.arguments as int? ?? 1;
          return RehabGameScreen(startingLevel: level);
        },

        "/adminDashboard": (c) => const AdminDashboardScreen(), 
      },
    );
  }
}